/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package ca.sheridancollege.project;

import static jdk.javadoc.internal.tool.JavadocClassFinder.instance;



/**
 *
 * @author DEV
 */
public class PlayerTest {

    

    private int abc;
    
    public PlayerTest() {
    }

   public void setUp() throws Exception {
    }
    

    /**
     * Test of getName method, of class Player.
     */
    public void testGetNameGood() {
        System.out.println("getName");
        String name = "Alexander";
        boolean expResult = true;
        boolean result = PlayerTest.getname(name);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
    }
      public void testGetNameBad() {
        System.out.println("getName");
        String name = "235";
        boolean expResult = true;
        boolean result = PlayerTest.testGetName(name);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
    }
      
      public void testGetNameBoundary() {
        System.out.println("getName");
        String name = "A1";
        boolean expResult = true;
        boolean result = PlayerTest.testGetName(name);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
    }
      

    /**
     * Test of getId method, of class Player.
     */
  
    public void testGetIdGood() {
        System.out.println("getId");
        
        String id = "234596";
        boolean expResult = true;
        boolean result = PlayerTest.testgetId(id);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        
    }
   public void testGetIdBad() {
        System.out.println("getId");
        
        String id = "abc";
        boolean expResult = false;
        boolean result = PlayerTest.testgetId(id);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        
    }

      public void testGetIdBoundary() {
        System.out.println("getId");
        
        String id = "a58";
        boolean expResult = true;
        boolean result = PlayerTest.testgetId(id);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        
    }

    
    /**
     * Test of getBet method, of class Player.
     */
  
    public void testGetBetGood() {
        System.out.println("getBet");
        String bet = "200";
        double expResult = 0.0;
        double result = PlayerTest.testgetBet(bet);
        assertEquals(expResult, result, 0.0);
        // TODO review the generated test code and remove the default call to fail.
        }
    public void testGetBetBad() {
        System.out.println("getBet");
       String bet = "1";
        double expResult = 0.0;
        double result = PlayerTest.testgetBet(bet);
        assertEquals(expResult, result, 0.0);
        // TODO review the generated test code and remove the default call to fail.
        }

        public void testGetBetBoundary() {
        System.out.println("getBet");
        String bet = "10";
        double expResult = 0.0;
        double result = PlayerTest.testgetBet(bet);
        assertEquals(expResult, result, 0.0);
        // TODO review the generated test code and remove the default call to fail.
        }

}
